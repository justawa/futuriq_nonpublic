<section>
  <div class="text-center">
    <img class="img-fluid mb-3" src="{{ asset('images/logo-tele.png') }}" />
  </div>
</section>