<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Partner;

class PartnerController extends Controller
{
    public function create()
    {
        return view('partner.create');
    }

    public function store(Request $request)
    {
        $partner = Partner::create($request);
        if($partner) {
            return redirect()->back()->with('success', 'Partner created successfully');
        } else {
            return redirect()->back()->with('failure', 'Failed to create partner');
        }
    }
}
